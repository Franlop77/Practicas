#Autor: Fran López Lizana
#Fecha: 03/11/2022

import time
import os


def caratula(fecha,proyecto):

    lineaEsquinaSuperiorIzq = ''
    lineaEsquinaSuperiorDch = ''
    lineaLateralIzq = ''
    lineaLateralDch = ''
    lineaEsquinaInferiorIzq = ''
    lineaEsquinaInferiorDch = ''
    lineaBasica=''
    lineaEnBlanco1=''   
    lineaEnBlanco2=''
    lineaEnBlanco3=''


    fechaHora = time.strftime("%H:%M:%S")
    fechaDia = fecha
    proyecto = 'Proyecto: ' + proyecto
    developer = 'Developer: Fran Lopez Lizana'

    sumaFechas = len(fechaHora) + len(fechaDia) 
    longitudProyecto = len(proyecto)
    longitudDeveloper = len(developer)
    

    ancho=80

    contador = 0 
    contador2 = 0 
    contador3 = 0 


    for i in range(0,ancho):
        if i == 0:
            lineaEsquinaSuperiorIzq += '╔'
            lineaEsquinaInferiorIzq += '╚'
            lineaLateralIzq += '║'
        elif i == ancho-1:
            lineaEsquinaSuperiorDch += '╗'
            lineaEsquinaInferiorDch += '╝'
            lineaLateralDch += '║'
        else:
            lineaBasica += '═'
            if contador < (ancho-2-sumaFechas): 
                lineaEnBlanco1 += ' '
                contador += 1
            if contador2 < (ancho-2-longitudProyecto):
                lineaEnBlanco2 += ' '
                contador2 += 1
            if contador3 < (ancho-2-longitudDeveloper):
                lineaEnBlanco3 += ' '
                contador3 += 1


    print (lineaEsquinaSuperiorIzq+lineaBasica+lineaEsquinaSuperiorDch)
    print (lineaLateralIzq+fechaDia+lineaEnBlanco1+fechaHora+lineaLateralDch)
    print (lineaLateralIzq+'\033[33m'+proyecto+'\033[0;m'+lineaEnBlanco2+lineaLateralDch)
    print (lineaLateralIzq+developer+lineaEnBlanco3+lineaLateralDch)
    print (lineaEsquinaInferiorIzq+lineaBasica+lineaEsquinaInferiorDch)


def limpiaPantalla():
    if os.name == "nt":
        os.system("cls")
    else:
        os.system("clear")