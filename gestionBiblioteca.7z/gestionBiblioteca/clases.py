class Autor:
    def __init__(self,nombre,apellido):
        self.nombre = nombre
        self.apellido = apellido

    ############# Metodos

    def mostrarAutor(self):
        print(self.nombre,self.apellido)


class Libro:
    def __init__(self,titulo,id,autor): #######
        self.titulo = titulo
        self.id = id
        self.autor = autor 

    ############# Metodos

    def aniadirAutor(self,autor):
        
        self.autor = autor

    def mostrarLibro(self):

        print('\033[93m'+'Titulo: '+'\033[0;m'+self.titulo )
        print('\033[93m'+'Id: '+'\033[0;m'+str(self.id) )
        print('\033[93m'+'Autor: '+'\033[0;m'+self.autor.nombre,self.autor.apellido,'\n')

    def obtenerTitulo(self):
        return self.titulo



class Biblioteca:

    def __init__(self):

        self.listaLibros = []

    ############# Metodos

    def aniadirLibro(self,libro):
        
        self.listaLibros.append(libro)
        print ('\n'+'\033[92m'+'Se ha añadido correctamente'+'\033[0;m')


    def borrarLibro(self,titulo):

        libroBorrado = False

        for libro in self.listaLibros:
            if Libro.obtenerTitulo(libro) == titulo:
                self.listaLibros.remove(libro) 
                print('\n'+'\033[92m'+'Se ha borrado correctamente'+'\033[0;m')
                libroBorrado = True

        if not libroBorrado:
            print('\n'+'\033[91m'+'El libro no existe'+'\033[0;m')

    def numeroLibros(self):

        return len(self.listaLibros)

    def mostrarBiblio(self):
        
        for libro in self.listaLibros:
            libro.mostrarLibro() 