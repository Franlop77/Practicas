import funciones as f
import clases as c


biblio = c.Biblioteca()

def mostrarMenu():

    print('\n1. Añadir libro a la biblioteca',
          '\n2. Mostrar la biblioteca',
          '\n3. Borrar libro de la biblioteca',
          '\n4. Mostrar el número de libros que componen la biblioteca',
          '\n5. Salir')


def comprobarVacio(variable):

    if variable == '':

        print('\n'+'\033[91m'+'No has introducido ningun valor'+'\033[0;m')
        gestionBiblio()

def aniadirLibroABiblioteca():

    nombreUsuario = (input('\nIntroduce el nombre del Autor del Libro: ')).title()
    comprobarVacio(nombreUsuario)

    apellidosUsuario = (input('Introduce el apellido del Autor del Libro: ')).title()
    comprobarVacio(apellidosUsuario)

    tituloUsuarioAdd = (input('Introduce el titulo del Libro: ')).title()
    comprobarVacio(tituloUsuarioAdd)
    
    try:

        idUsuario = int(input('Introduce el id del Libro: '))
       
    except ValueError or UnboundLocalError:
        print('\n'+'\033[91m'+'El id del libro debe ser un número y no estar vacio'+'\033[0;m')
        gestionBiblio()

    autor = c.Autor(nombreUsuario,apellidosUsuario)
    libro = c.Libro(tituloUsuarioAdd,idUsuario,autor)


    idRepetido = False
    for libroBiblioteca in biblio.listaLibros:
        if libroBiblioteca.id == idUsuario:
            idRepetido = True


    if not idRepetido:
        libro.aniadirAutor(autor)
        biblio.aniadirLibro(libro)
    else:
        print('\033[91m'+'Este id ya existe'+'\033[0;m')




def mostrarBiblioteca():

    biblio.mostrarBiblio()


def borrarLibro():

    tituloUsuarioDel = input('Introduce el titulo del Libro que desea borrar: ')
    comprobarVacio(tituloUsuarioDel)

    biblio.borrarLibro(tituloUsuarioDel)


def numeroLibros():

    print ('Hay '+'\033[36m'+str(biblio.numeroLibros())+'\033[0;m'+' libros en la biblioteca actualmente')


f.limpiaPantalla()
f.caratula('22/12/2022','Gestión_Biblioteca')

def gestionBiblio():
    while True:
        try:
            mostrarMenu()

            opcion = int(input('\nIntroduzca una opcion: '))


            if opcion == 1:

                f.limpiaPantalla()
                f.caratula('22/12/2022','Gestión_Biblioteca')
                aniadirLibroABiblioteca()
                

            elif opcion == 2:

                f.limpiaPantalla()
                f.caratula('22/12/2022','Gestión_Biblioteca')
                mostrarBiblioteca()

            elif opcion == 3:

                f.limpiaPantalla()
                f.caratula('22/12/2022','Gestión_Biblioteca')
                borrarLibro()

            elif opcion == 4:

                f.limpiaPantalla()
                f.caratula('22/12/2022','Gestión_Biblioteca')
                numeroLibros()

            elif opcion == 5:

                f.limpiaPantalla()
                exit()

            elif opcion > 5 or opcion <= 0:
                f.limpiaPantalla()
                f.caratula('22/12/2022','Gestión_Biblioteca')
                print('\033[91m'+'Opción no válida\n'+'\033[0;m')

        except ValueError:
            f.limpiaPantalla()
            f.caratula('22/12/2022','Gestión_Biblioteca')
            print('\n'+'\033[91m'+'Debes introducir un numero'+'\033[0;m')

    

gestionBiblio()